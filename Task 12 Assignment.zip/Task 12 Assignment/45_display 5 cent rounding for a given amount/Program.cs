﻿/*45) WAP to do 5 cent rounding given amount.
     Ex : 5.00  after rounding 5.00 
	  5.01  after rounding 5.00
	  5.02  after rounding 5.00
	  5.03 after rounding  5.05
	  5.04  after rounding 5.05
	  5.05  after rounding 5.05
	  5.06  after rounding 5.05
	  5.07  after rounding 5.05
      5.08  after rounding 5.10
	  5.09  after rounding 5.10
	  5.10  after rounding 5.10
*/
using System;

namespace _45_display_5_cent_rounding_for_a_given_amount
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            { 
            decimal num;
            Console.WriteLine("Enter the value of num");
            num = Convert.ToDecimal(Console.ReadLine());
            Console.WriteLine("The rounding of num is : {0}", Math.Round(Math.Round(num / 5, 2) * 5, 2));
            Console.ReadLine();
        }
    }
   }
}